# MDV Global Delivery Intelligence — Cloudflare Worker

## Why this version?
Your Cloudflare project is set up as a **Worker** (not Pages), so this version
uses a single `worker.js` file that handles everything — the API call to Airtable
and serving the dashboard HTML. No Pages Functions folder needed.

## Files
```
mdv-worker/
├── wrangler.toml    ← Cloudflare Worker config
└── worker.js        ← Single file: API + dashboard HTML
```

## Deploy Steps

### 1 — Replace your worker.js in GitHub
Copy `worker.js` and `wrangler.toml` into your existing `RyanJ1996/GlobalGoodsIn` repo
(replacing any existing worker.js), then commit and push:
```bash
git add worker.js wrangler.toml
git commit -m "Add MDV delivery dashboard worker"
git push
```
Cloudflare will auto-deploy from your connected GitHub repo.

### 2 — Add your Airtable API key (the important bit)
In Cloudflare Dashboard:
1. Go to **Workers & Pages** → your worker (`mdv-delivery-dashboard`)
2. Click **Settings** → **Variables and Secrets**
3. Under **Secret** (not plain Variable — keeps it encrypted), click **Add**:
   - **Variable name:** `AIRTABLE_API_KEY`
   - **Value:** Your Airtable personal access token
4. Click **Deploy** to redeploy with the secret active

Get your Airtable token from: https://airtable.com/create/tokens
Scopes needed: `data.records:read` on the `MDV - Production & Delivery` base

### 3 — Done
Your dashboard is live at your worker URL, e.g.:
`https://mdv-delivery-dashboard.YOUR-SUBDOMAIN.workers.dev`

## How it works
- `GET /api/shipments` → Worker fetches from Airtable using the secret key
- `GET /*` → Worker serves the dashboard HTML
- The Airtable API key never reaches the browser — it stays in the Worker
